#include<iostream>
#include<string>
#include "Room.h"
#include "Item.h"
using namespace std;

Room::Room()
{
    locked = false;
}

bool Room::isLocked()
{
    return locked;
}

int Room::getRoomItemType()
{
    int type = roomItem.getItemType();
    return type;
}

string Room::getRoomType()
{
    return roomType;
}

void Room::setRoomType(string type)
{
    roomType = type;
}


void Room::changeLockRoom(bool lockState)
{
    locked = lockState;
}

void Room::setRoomItemType(int type)
{
    roomItem.setItemType(type);
}
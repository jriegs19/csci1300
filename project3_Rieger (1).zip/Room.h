#ifndef ROOM_H
#define ROOM_H
#include<string>
#include "Item.h"

class Room
{
    private:
        bool locked;
        string roomType;
        Item roomItem;
        
    public:
        Room();
        //----------Getters
        bool isLocked();
        int getRoomItemType();
        string getRoomType();
        //---------Setters
        void changeLockRoom(bool);
        void setRoomItemType(int);
        void setRoomType(string);

};

#endif